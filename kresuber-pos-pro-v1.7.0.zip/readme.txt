=== Kresuber POS Pro ===
Stable tag: 1.7.0
Description: Professional POS System.